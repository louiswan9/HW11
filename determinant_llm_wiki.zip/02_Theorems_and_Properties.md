# 02｜核心公理、性質與等價定理

相關頁面：[[00_Index]] | [[01_Core_Definitions]] | [[03_Step_by_Step_Procedures]] | [[04_Common_Pitfalls]]

## 1. 三大基本公理（定義行列式的唯一規則） `[Source 2]`

任何階數的行列式函數皆可由以下三條公理唯一決定：

1. **正規化（Normalization）**：
   單位矩陣的行列式恆等於 $1$：
   $$\det(I) = 1$$
2. **交替性（Alternating）**：
   交換矩陣的任意兩列，行列式變號：
   $$\det(A_{\text{swapped}}) = -\det(A)$$
3. **多線性（Multilinearity）**：
   **固定其他列時**，行列式對單一列的加法與純量乘法具有線性：
   $$\det(\dots, \alpha r_i + \beta s_i, \dots) = \alpha \det(\dots, r_i, \dots) + \beta \det(\dots, s_i, \dots)$$

## 2. 由公理推導的列運算與零值性質 `[Source 2, 3]`

* **兩列相同或成比例**：若矩陣有兩列完全相同（或某一列為另一列的純量倍），則 $\det(A) = 0$（證明：交換兩相同列得 $\det(A) = -\det(A) \implies 2\det(A) = 0$）。
* **含有全零列或全零欄**：若矩陣包含任一全零列或全零欄，則 $\det(A) = 0$。
* **基本列運算（ERO）對行列式的影響**：
  | 列運算操作 | 符號表示 | 對 $\det(A)$ 的影響 |
  | :--- | :--- | :--- |
  | 交換兩列 | $R_i \leftrightarrow R_j$ | 乘以 $-1$（變號） |
  | 某列乘非零常數 | $R_i \leftarrow cR_i$ | 乘以 $c$ |
  | 某列加上另一列倍數 | $R_i \leftarrow R_i + cR_j$ | **完全不變（$\times 1$）** |

## 3. 矩陣結構與代數運算性質 `[Source 3]`

* **三角矩陣與對角矩陣**：
  上三角矩陣 $U$、下三角矩陣 $L$ 與對角矩陣 $D$ 的行列式等於**主對角線元素乘積**：
  $$\det(U) = \prod_{i=1}^n u_{ii}$$
* **矩陣乘積性質**：
  $$\det(AB) = \det(A)\det(B), \quad \det(A^k) = (\det(A))^k$$
* **轉置不變性**：
  $$\det(A^T) = \det(A)$$
  因此所有對「列（Row）」成立的行列式性質，對「欄（Column）」亦完全成立。
* **反矩陣行列式**：
  當 $\det(A) \neq 0$（$A$ 可逆）時：
  $$\det(A^{-1}) = \frac{1}{\det(A)}$$
* **純量乘矩陣**：
  若 $A \in \mathbb{R}^{n \times n}$，則每列皆提出一個 $c$，共有 $n$ 列：
  $$\det(cA) = c^n \det(A)$$

## 4. 可逆矩陣等價定理（Invertible Matrix Theorem 串聯） `[Source 3]`

對於 $n \times n$ 方形矩陣 $A$，以下條件彼此邏輯等價：

1. $\det(A) \neq 0$
2. $A$ 可逆（存在反矩陣 $A^{-1}$，為非奇異矩陣）
3. $A$ 經過高斯消去後擁有完整的 $n$ 個非零主元（pivots）
4. $\text{rank}(A) = n$（滿秩）
5. $A$ 的零空間僅包含零向量：$N(A) = \{\vec{0}\}$
6. $A$ 的欄空間張滿整個空間：$C(A) = \mathbb{R}^n$
7. $A$ 的欄向量線性獨立，且 $A$ 的列向量線性獨立
8. 線性方程組 $Ax = b$ 對任意向量 $b \in \mathbb{R}^n$ 皆有唯一解
