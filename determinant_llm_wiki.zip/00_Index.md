# 📚 LLM Wiki：行列式（Determinant）知識地圖與索引

本知識庫由線性代數課程講義《行列式（Determinant）》切分為 5 個獨立單元後，經過提取、除噪、符號一致性校正與交叉關聯建構而成，作為後續教學簡報生成之唯一真實來源（Single Source of Truth）。

## 1. Ingest 資料來源清單（Sources）

* **Source 1（Pages 1–13）**：行列式的基本定義、低階計算與幾何意義（見 [[01_Core_Definitions]]）
* **Source 2（Pages 14–24）**：三大基本公理與列運算推導性質（見 [[02_Theorems_and_Properties]]）
* **Source 3（Pages 25–38）**：高斯消去法計算、PLU 分解與矩陣運算性質（見 [[02_Theorems_and_Properties]]、[[03_Step_by_Step_Procedures]]）
* **Source 4（Pages 39–51）**：排列公式（Permutation）與餘因子展開（Cofactor Expansion）（見 [[01_Core_Definitions]]、[[03_Step_by_Step_Procedures]]）
* **Source 5（Pages 52–63）**：伴隨矩陣（Adjugate）與克拉瑪法則（Cramer's Rule）（見 [[03_Step_by_Step_Procedures]]、[[04_Common_Pitfalls]]）

## 2. 概念依賴與演進脈絡

```text
[幾何直覺：有向面積/體積縮放 (Source 1)]
        │
        ▼
[三大基本公理：正規化、交替性、多線性 (Source 2)]
        ├──► 推導高效率演算法 ──► [高斯消去法 O(n³) 與 PLU 分解 (Source 3)]
        └──► 推導一般展開式 ────► [排列公式 n! 與 Cofactor 展開 (Source 4)]
                                          │
                                          ▼
                            [理論閉式解：Adjugate 反矩陣與 Cramer's Rule (Source 5)]
```

## 3. Wiki 檔案導覽

* `00_Index.md`：知識地圖、資料來源溯源與模組關聯。
* `01_Core_Definitions.md`：嚴格數學定義、符號規範與幾何直覺。
* `02_Theorems_and_Properties.md`：三大基本公理、列運算規則與可逆矩陣等價定理。
* `03_Step_by_Step_Procedures.md`：三大標準計算流程（高斯消去、餘因子展開、伴隨矩陣與 Cramer's Rule）及時間複雜度比較。
* `04_Common_Pitfalls.md`：常見觀念誤區、邊界條件檢查與反例。
