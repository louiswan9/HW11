# 01｜嚴格數學定義與符號表

相關頁面：[[00_Index]] | [[02_Theorems_and_Properties]] | [[04_Common_Pitfalls]]

## 1. 行列式函數（Determinant Function） `[Source 1]`

* **定義域與對應域**：行列式是將 $n \times n$ 方形矩陣映射到單一純量（實數）的函數，記作：
  $$\det: \mathbb{R}^{n \times n} \rightarrow \mathbb{R} \quad \text{或寫作 } \det(A) \text{、}|A|$$
* **前提限制**：只有**方形矩陣（Square Matrix）**才定義行列式。

## 2. 二階與三階基礎公式 `[Source 1]`

* **二階行列式（$2 \times 2$）**：
  $$\det\begin{pmatrix} a & b \\ c & d \end{pmatrix} = ad - bc$$
  即主對角線元素乘積減去副對角線元素乘積。
* **三階行列式（$3 \times 3$ 遞迴展開）**：
  沿第一列依「$+ - +$」交錯符號降階為三個 $2 \times 2$ 子行列式：
  $$\det(A) = a_{11}\begin{vmatrix} a_{22} & a_{23} \\ a_{32} & a_{33} \end{vmatrix} - a_{12}\begin{vmatrix} a_{21} & a_{23} \\ a_{31} & a_{33} \end{vmatrix} + a_{13}\begin{vmatrix} a_{21} & a_{22} \\ a_{31} & a_{32} \end{vmatrix}$$

## 3. 幾何意義：縮放倍率、方向性與退化 `[Source 1]`

對於線性變換 $x \mapsto Ax$（其中 $A \in \mathbb{R}^{n \times n}$）：

1. **縮放倍率 $|\det(A)|$**：
   * 在二維空間中，兩欄向量 $a_1, a_2$ 張成（span）的平行四邊形面積為 $|\det(A)|$。
   * 在三維空間中，三欄向量 $a_1, a_2, a_3$ 張成的平行六面體體積為 $|\det(A)|$；推廣至 $n$ 維空間則為超體積（hypervolume）縮放倍率。
2. **空間方向 $\text{sgn}(\det(A))$**：
   * $\det(A) > 0$：保持空間原有方向（正向，如二維逆時針或三維右手定則）。
   * $\det(A) < 0$：空間方向發生反轉（負向，如鏡射翻轉）。
3. **維度壓縮（退化） $\det(A) = 0$**：
   * 空間被壓縮到更低維度（例如二維平面被壓成直線，面積變為 $0$）。
   * 表示矩陣的行向量或列向量**線性相依（Linearly Dependent）**，矩陣不可逆。

## 4. 排列（Permutation）與餘因子相關定義 `[Source 4]`

* **一般排列公式（Leibniz Formula）**：
  $$\det(A) = \sum_{\sigma \in S_n} \text{sgn}(\sigma) \prod_{i=1}^{n} a_{i, \sigma(i)}$$
  其中 $S_n$ 為 $\{1, \dots, n\}$ 的所有 $n!$ 個排列，$\text{sgn}(\sigma) \in \{+1, -1\}$ 依排列所需的列交換次數（偶排列為 $+1$，奇排列為 $-1$）決定。
* **子行列式（Minor $M_{ij}$）**：
  刪去原矩陣 $A$ 的第 $i$ 列與第 $j$ 欄後所得的 $(n-1)\times(n-1)$ 子矩陣，其行列式 $\det(M_{ij})$ 稱為元素 $a_{ij}$ 的 minor。
* **代數餘子式（Cofactor $C_{ij}$）**：
  帶有位置棋盤正負號因子的 minor：
  $$C_{ij} = (-1)^{i+j}\det(M_{ij})$$

## 5. 伴隨矩陣（Adjugate Matrix） `[Source 5]`

* 將矩陣 $A$ 所有元素的代數餘子式排成 Cofactor Matrix $C$ 後取轉置，稱為伴隨矩陣：
  $$\text{adj}(A) = C^T$$
